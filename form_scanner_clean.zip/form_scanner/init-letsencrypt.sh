#!/usr/bin/env bash
# Run this ONCE on the server, before the first `docker compose up -d`.
# It creates a temporary self-signed cert so nginx can start, requests the
# real Let's Encrypt certificate over HTTP, then swaps the real one in.
#
# Usage:
#   chmod +x init-letsencrypt.sh
#   ./init-letsencrypt.sh

set -e

DOMAIN="scanner.agentkikir.cloud"
EMAIL="you@example.com"        # <-- change this, used for renewal notices
STAGING=0                       # set to 1 first to test without hitting rate limits

DATA_PATH="./certbot/conf"
mkdir -p "$DATA_PATH/live/$DOMAIN"

echo "### Creating temporary self-signed certificate for $DOMAIN ..."
docker run --rm -v "$(pwd)/certbot/conf:/etc/letsencrypt" \
  alpine/openssl req -x509 -nodes -newkey rsa:2048 -days 1 \
  -keyout "/etc/letsencrypt/live/$DOMAIN/privkey.pem" \
  -out "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" \
  -subj "/CN=localhost"

echo "### Starting nginx + app ..."
docker compose up -d nginx app

echo "### Deleting temporary certificate ..."
docker run --rm -v "$(pwd)/certbot/conf:/etc/letsencrypt" \
  alpine sh -c "rm -rf /etc/letsencrypt/live/$DOMAIN /etc/letsencrypt/archive/$DOMAIN /etc/letsencrypt/renewal/$DOMAIN.conf"

STAGING_ARG=""
if [ "$STAGING" != "0" ]; then STAGING_ARG="--staging"; fi

echo "### Requesting real Let's Encrypt certificate for $DOMAIN ..."
docker run --rm \
  -v "$(pwd)/certbot/conf:/etc/letsencrypt" \
  -v "$(pwd)/certbot/www:/var/www/certbot" \
  certbot/certbot certonly --webroot -w /var/www/certbot \
  $STAGING_ARG \
  --email "$EMAIL" --agree-tos --no-eff-email \
  -d "$DOMAIN"

echo "### Reloading nginx with the real certificate ..."
docker compose exec nginx nginx -s reload

echo "### Starting the certbot auto-renewal container ..."
docker compose up -d certbot

echo "Done. https://$DOMAIN should now be live."
