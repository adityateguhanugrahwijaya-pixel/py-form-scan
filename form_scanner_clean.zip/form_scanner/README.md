# Form Scanner — Student Lifestyle & Aspirations Survey

Turns phone photos of your 50 filled-in paper forms into structured data,
the same way exam-scanning machines work: corner markers align/flatten the
photo, checkbox/radio fill is detected automatically, and handwritten
answers are cropped out as clean images.

## How it works

1. **`prepare_template.py`** — one-time step. Adds a white margin + 4
   corner markers to your form and outputs `output/printable_form.pdf`.
   **Print/photocopy this version**, not the original — the markers are
   what make phone-photo alignment reliable.

2. **Students fill in the printed forms** by hand as normal.

3. **Photograph each form**, either:
   - **One at a time from a phone browser** — run `python3 app.py`, then
     open `http://<your-computer's-ip>:5001` on your phone (same wifi), or
     the public HTTPS URL if deployed (see below). Take the photo, tap
     upload, get results instantly.
   - **In bulk** — take all photos with your phone's normal camera app,
     transfer them into one folder, then run:
     ```
     python3 batch_scan.py photos_folder/ --out results.xlsx
     ```

4. **Results**:
   - `results.xlsx` — one row per form: gender, social media time, study
     time, which platforms were checked, and a link to each handwritten
     answer's cropped image.
   - `crops/<form_id>_<field>.png` — cropped image of each handwritten
     answer (name, class, age, "other" specify, career, career reason).
     Open these to transcribe by eye, or feed them into an OCR/handwriting
     model later if you want full text automatically.

## Setup (local, no Docker)

```bash
pip install opencv-contrib-python pymupdf flask pandas openpyxl
python3 app.py
```

## Deploying to a server — nginx + Let's Encrypt (scanner.agentkikir.cloud)

Runs the Flask app behind **nginx**, with a free auto-renewing
**Let's Encrypt** TLS certificate, via `docker compose`.

**Before you start:**
- Point `scanner.agentkikir.cloud`'s DNS **A record** at your server's
  public IP address.
- Open ports **80** and **443** on the server's firewall — both are
  required for Let's Encrypt to verify domain ownership.
- Confirm DNS has actually propagated: `dig +short scanner.agentkikir.cloud`
  should return your server's IP before you continue.

### 1. Get the project onto the server and build

```bash
cd form_scanner
docker compose build
```

### 2. Bootstrap the first TLS certificate (one-time)

```bash
nano init-letsencrypt.sh   # change EMAIL="you@example.com" to your real email
chmod +x init-letsencrypt.sh
./init-letsencrypt.sh
```

This script: starts nginx with a throwaway self-signed cert so it can bind
to port 443 → requests the real certificate from Let's Encrypt over port 80
→ swaps it in → reloads nginx → starts the `certbot` container that keeps
the cert renewed from then on.

### 3. Confirm it's live

```bash
docker compose ps                       # all 3 containers should be "Up"
curl -I https://scanner.agentkikir.cloud
```

Open `https://scanner.agentkikir.cloud` on a phone — it should load the
camera capture page with a padlock in the address bar.

### Updating the app later

```bash
docker compose build app
docker compose up -d app
```

(nginx and certbot don't need to be touched for app code changes.)

### Password-protect it (recommended)

This form collects students' names and ages, and the domain is public.
Turn on HTTP basic auth in front of it:

```bash
mkdir -p nginx
docker run --rm -v $(pwd)/nginx:/etc/nginx httpd:2.4-alpine \
  htpasswd -bc /etc/nginx/.htpasswd teacher "choose-a-strong-password"
```

Then uncomment the two `auth_basic` lines in `nginx/conf.d/scanner.conf`
and reload:

```bash
docker compose exec nginx nginx -s reload
```

### Where data lives / logs

- Uploaded photos + cropped answers: `./data/uploads`, `./data/crops` on
  the host (Docker volumes — survive rebuilds/restarts). Back these up
  periodically, or run `batch_scan.py` against `data/uploads` to
  regenerate `results.xlsx`.
- TLS certs: `./certbot/conf` on the host.
- Logs: `docker compose logs -f app` / `docker compose logs -f nginx` /
  `docker compose logs -f certbot`

### Troubleshooting

- **Certbot fails at the HTTP-01 challenge** → almost always DNS not
  propagated yet, or port 80 blocked/occupied by something else on the
  server. Re-check `dig +short scanner.agentkikir.cloud` and
  `sudo ss -tlnp | grep :80` before retrying.
- **Rate limited by Let's Encrypt** → set `STAGING=1` in
  `init-letsencrypt.sh` while testing (staging certs aren't trusted by
  browsers but don't count against the real rate limit), then switch back
  to `STAGING=0` for the real cert once everything else works.
- **502 Bad Gateway from nginx** → the `app` container isn't up yet or
  crashed; check `docker compose logs -f app`.

## Files

| File | Purpose |
|---|---|
| `template_config.py` | Exact pixel/point coordinates of every field, extracted directly from your PDF |
| `prepare_template.py` | Adds corner markers → printable PDF |
| `scan_form.py` | Core pipeline: align one photo → detect checks → crop answers |
| `batch_scan.py` | Run `scan_form` over a whole folder → one spreadsheet |
| `app.py` + `capture.html` | Phone-browser camera capture → instant scan |
| `Dockerfile` | Container image for `app.py` (served via gunicorn) |
| `docker-compose.yml` | Runs `app` + `nginx` (reverse proxy/TLS) + `certbot` (auto-renewal) |
| `nginx/conf.d/scanner.conf` | nginx reverse proxy + TLS config |
| `init-letsencrypt.sh` | One-time script to bootstrap the first TLS certificate |

## Photo-taking tips (matters more than anything else)

- All **4 corner markers must be visible** and roughly flat/undistorted.
- Even lighting, no strong shadow across the page.
- Fill checkboxes/circles with a solid dark mark, not a light tick.
- If a scan fails alignment, `batch_scan.py` logs it to
  `results_failures.csv` instead of silently giving wrong data — retake
  those specific photos.

## If your form design changes

The regions in `template_config.py` are specific to
`student_survey_form.pdf`'s exact layout. If you edit the form (move
fields, add/remove questions), you'll need to re-extract coordinates:

```python
import fitz
doc = fitz.open("your_form.pdf")
for d in doc[0].get_drawings():
    print(d["rect"], d.get("type"))
```

and update the `offset(...)` calls in `template_config.py` to match.
